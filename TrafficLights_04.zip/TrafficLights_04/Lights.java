package TrafficLights_04;

public enum Lights {
    RED,
    GREEN,
    YELLOW;
}
