package CardSuit_01;

public enum Suits {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
